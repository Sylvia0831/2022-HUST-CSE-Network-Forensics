﻿// JScript File

function check(name,i)
{
		var val=document.form1.page.value;
		var path;
		if (val <= 1)
		{			path = name + "-1.html";
		}
		else if (val <= i)
		{
			var str=val.toString();
			path = name+"-"+str+".html";
		}
		else{
			val = i;
			var str=val.toString();
			path = name+"-"+str+".html";
		}
		document.location=path;
}
function check2(name,i)
{
		var val=document.form2.page.value;
		var path;
		if (val <= 1)
		{			path = name + "-1.html";
		}
		else if (val <= i)
		{
			var str=val.toString();
			path = name+"-"+str+".html";
		}
		else{
			val = i;
			var str=val.toString();
			path = name+"-"+str+".html";
		}
		document.location=path;
}
function showAll(c,d)
{
		var c = document.getElementById(c);
		var d = document.getElementById(d);
		c.style.display = "none";
		d.style.display = "block";
}